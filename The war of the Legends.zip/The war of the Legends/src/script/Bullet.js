export default class Bullet extends Laya.Image {
    constructor() {
        super();
        // //设置单例的引用方式，方便其他类引用
        Bullet.instance = this;
        //加载场景文件
        this.showBullet();
        this.width = 9;
        this.height = 21;
    }
    showBullet() {
        Laya.Animation.createFrames(["comp/bullet1.png", "comp/bullet2.png"], "bullet");
        // 创建body作为动画的载体
        this.body = new Laya.Animation();
        this.addChild(this.body);
        this.playAction("bullet");
    }
    playAction(action) {
        this.body.play(0, true, action);
    }
    onBulletLoop() {
        this.y -= 5;
    }
}