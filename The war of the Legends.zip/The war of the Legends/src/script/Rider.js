export default class Rider extends Laya.Sprite {
    constructor() {
        super();
        // //设置单例的引用方式，方便其他类引用
        Rider.instance = this;
        //加载场景文件
        this.showRider();
        this.width = 99;
        this.height = 124;
    }
    showRider() {
        Laya.Animation.createFrames(["comp/hero_fly1.png", "comp/hero_fly2.png"], "hero_fly");
        //缓存击中爆炸效果
        Laya.Animation.createFrames(["comp/hero_down1.png", "comp/hero_down2.png",
            "comp/hero_down3.png", "comp/hero_down4.png"
        ], "hero_down");
        // 创建body作为动画的载体
        this.body = new Laya.Animation();
        this.addChild(this.body);
        this.playAction("hero_fly", 0);
    }
    playAction(action, status) {
        if (status == 0) {
            this.body.play(0, true, action);
        } else {
            action = "hero_down";
            this.body.play(0, false, action);
            this.body.on(Laya.Event.COMPLETE, this, function() {
                this.body.destroy();
            })
        }
    }
}