import Rider from "./Rider";
import Enemy from "./Enemy";
import Bullet from "./Bullet";
export default class Background extends Laya.Scene {
    constructor() {
        super();
        // //设置单例的引用方式，方便其他类引用
        Background.instance = this;
        this.time = 0;
        this.time2 = 0;
        this.tick = 0;
        this.tick1 = 0;
        this.showBg();
        this.onloaded();
    }
    showBg() {
        this.bg1 = new Laya.Sprite();
        this.bg2 = new Laya.Sprite();

        this.bg1.loadImage("comp/background.png")
        this.bg2.loadImage("comp/background.png")

        Laya.stage.addChild(this.bg1);
        Laya.stage.addChild(this.bg2);

        this.bg2.pos(0, -852);
        // 在定时器里面实现背景滚动
        Laya.timer.frameLoop(1, this, this.onLoop);

        this.array = [];
        this.array1 = [];
    }
    onLoop() {
            this.bg1.y += 1;
            if (this.bg1.y + this.y >= 852) {
                this.bg1.y -= 852 * 2;
            }
            this.bg2.y += 1;
            if (this.bg2.y + this.y >= 852) {
                this.bg2.y -= 852 * 2;
            }

            this.time += Laya.timer.delta;
            if (this.time > 800) {
                this.createEnemy();
                this.time = 0;
            }
            for (let i in this.array) {
                let enemy = this.array[i];
                if (enemy.destroyed) {
                    this.remove(this.array, enemy);
                    continue;
                }
                enemy.onLoop();
                if (Math.abs(this.rider.x - enemy.x) < this.rider.width / 2 + enemy.width / 2 && Math.abs(this.rider.y - enemy.y) < this.rider.height / 2 + enemy.height / 2) {
                    var temp = enemy.body._actionName.split("_");
                    if (temp[1] == "fly") {
                        enemy.playAction(temp[0]);
                        this.rider.playAction(this.rider.body._actionName, 1)
                        this.tick += Laya.timer.delta;
                        if (this.tick > 200) {
                            enemy.destroy();
                            this.rider.destroy();
                            this.tick = 0;
                        }
                    }
                    break;
                }
            }

            this.time2 += Laya.timer.delta;
            if (this.time2 > 4) {
                this.createBullet();
                this.time2 = 0;
            }
            for (let i in this.array1) {
                let bullet = this.array1[i];
                if (bullet.destroyed) {
                    this.remove(this.array1, bullet);
                    continue;
                }
                bullet.onBulletLoop();
                for (let j in this.array) {
                    let enemy = this.array[j];
                    if (enemy.destroyed) {
                        this.remove(this.array, enemy);
                        continue;
                    }
                    if (Math.abs(bullet.x - enemy.x) < bullet.width / 2 + enemy.width / 2 && Math.abs(bullet.y - enemy.y) < bullet.height / 2 + enemy.height / 2) {
                        var temp = enemy.body._actionName.split("_");
                        if (temp[1] == "fly") {
                            enemy.playAction(temp[0]);
                            this.tick1 += Laya.timer.delta;
                            if (this.tick1 > 200) {
                                enemy.destroy();
                                bullet.destroy();
                                this.tick1 = 0;
                            }

                        }
                        continue;
                    }
                    if (enemy.y >= 852) {
                        enemy.y -= 852 * 2;
                    }
                }
                if (bullet.y <= 0) {
                    bullet.destroy();
                }
            }
        }
        //创建敌舰
    createEnemy() {
        let enemy = new Enemy();
        enemy.pivot(enemy.width / 2, enemy.height / 2);
        enemy.pos(Math.random() * (Laya.stage.width - enemy.width), 0)
        Laya.stage.addChild(enemy);
        this.array.push(enemy);
    }

    //创建子弹
    createBullet() {
        let bullet = new Bullet();
        bullet.pivot(bullet.width / 2, bullet.height / 2);
        bullet.pos(this.rider.x, this.rider.y - this.rider.height / 2)
        Laya.stage.addChild(bullet);
        this.array1.push(bullet);
    }

    onloaded() {
        this.rider = new Rider();
        this.rider.pos(250, 600);
        this.rider.pivot(this.rider.width / 2, this.rider.height / 2);
        Laya.stage.addChild(this.rider);
        Laya.stage.on(Laya.Event.MOUSE_MOVE, this, this.onMouseMove);
    }
    onMouseMove() {
        this.rider.pos(Laya.stage.mouseX, Laya.stage.mouseY);
    }
    indexOf(array, val) {
        for (var i = 0; i < array.length; i++) {
            if (array[i] == val) return i;
        }
        return -1;
    };
    remove(array, val) {
        var index = array.indexOf(val);
        if (index > -1) {
            array.splice(index, 1);
        }
    };
}